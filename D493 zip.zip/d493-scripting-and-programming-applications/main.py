import requests


#Creates a class with the instance variables for the specific location and date
class Weather:
    def __init__(self, latitude, longitude, month, day):
        self.latitude = latitude
        self.longitude = longitude
        self.month = month
        self.day = day
        self.year = None
        self.avg_temp = None
        self.min_temp = None
        self.max_temp = None
        self.avg_wind_speed = None
        self.min_wind_speed = None
        self.max_wind_speed = None
        self.sum_precipitation = None
        self.min_precipitation = None
        self.max_precipitation = None

    #Creates an API url with the specific location and date
    def retrieve_weather_data(self, year):
        url = f"https://archive-api.open-meteo.com/v1/archive?latitude={self.latitude}&longitude={self.longitude}&start_date={year}-{self.month:02d}-{self.day:02d}&end_date={year}-{self.month:02d}-{self.day:02d}&daily=temperature_2m_mean,precipitation_sum,wind_speed_10m_max&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&timezone=America%2FLos_Angeles"

        #Makes GET requests to the API to retrieve data from the 'daily' dictionary
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if 'daily' in data:
                daily_data = data['daily']
                mean_temp = daily_data.get('temperature_2m_mean', [None])[0]
                max_wind_speed = daily_data.get('wind_speed_10m_max', [None])[0]
                precipitation_sum = daily_data.get('precipitation_sum', [None])[0]
                return mean_temp, max_wind_speed, precipitation_sum
        return None, None, None

#Sets the values for the specific location and date
latitude = 32.7157
longitude = -117.1647
month = 4
day = 8

#Creates an object with the latitude, longitude, month, and day values
weather_data = Weather(latitude, longitude, month, day)

#Creates empty lists to store mean temps, max wind speeds, and precipitation sums for each year
mean_temps = []
max_wind_speeds = []
precipitation_sums = []

#Retrieves data for each year from 2020-2024. The lists will contain the mean temps, max wind speeds, and precipitation sums from the past 5 years.
for year in range(2020, 2025):
    mean_temp, max_wind_speed, precipitation_sum = weather_data.retrieve_weather_data(year)
    if all([mean_temp is not None, max_wind_speed is not None, precipitation_sum is not None]):
        mean_temps.append(mean_temp)
        max_wind_speeds.append(max_wind_speed)
        precipitation_sums.append(precipitation_sum)

#Calculates the mean temperature from the past 5 years
mean_temp_5yr = sum(mean_temps) / len(mean_temps) if mean_temps else None

#Finds the maximum wind speed from the past 5 years
max_wind_speed = max(max_wind_speeds) if max_wind_speeds else None

#Calculates the total precipitation from the past 5 years
total_precipitation = sum(precipitation_sums) if precipitation_sums else None

#Prints out the statements and output for mean temp, max wind speed, and precipitation sum
print("Mean temperature in Fahrenheit:", mean_temp_5yr)
print("Maximum wind speed in mph:", max_wind_speed)
print("Precipitation sum in inches:", total_precipitation)
