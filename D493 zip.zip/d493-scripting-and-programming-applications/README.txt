Weather Data Project

The purpose of this project was to create a Python program with the PyCharm IDE to analyze historical weather data
from the OpenMeteo API. Weather data from the previous 5 years of a specific location and date had to be retrieved for
the program to be successful. To start the code, the library named "requests" was imported to allow HTTP requests.
The class named "Weather" was created and an instance method, "__init__", that initialized the class instances was
also created. The instance method was given the following parameters: self, latitude, longitude, month, and day. The
parameter "self" is a parameter that references the instance that was created. The other parameters were used for instance
attributes that were created with the dot notation such as "self.latitude."

Another instance method was created, "retrieve_weather_data," within the "Weather" class. The URL contains strings for
the latitude, longitude, year, month, and day as well as the parameters for the OpenMeteo API. The URL is used to retrieve
weather data for a specific date and location. A GET request was made to the API URL with the "requests.get" method to retrieve
the historical weather data for the specified location and date. If the status code was 200, it means that the response
was successful, and it retrieves the JSON data from the response using the "json" method. If the "daily" key exists in the
JSON data, it retrieves the daily weather data from the "daily" dictionary. It also retrieves the mean temperature,
maximum wind speed, and precipitation sum from the daily data; it does this with the "get" method and gives it a default
value of "None" just in case there are instances in which the data cannot be retrieved. It returns the tuple containing
the mean temperature, maximum wind speed, and precipitation sum. If the variables aren't available, it returns "None"
for the variables.

These next few lines of code set the values for latitude, longitude, month, and day. This is the input that is required
to run the program:
latitude = 32.7157
longitude = -117.1647
month = 4
day = 8

This line of code initializes a "WeatherData" object with the specified latitude, longitude, month, and day.
This object is used to retrieve the weather data:
weather_data = Weather(latitude, longitude, month, day)

These next few lines of code create an empty list to store mean temperatures, maximum wind speeds, and precipitation
sums for each year.
mean_temps = []
max_wind_speeds = []
precipitation_sums = []

For the next few lines, the code creates a loop that retrieves weather data for each year using the "retrieve_weather_data"
method of the "Weather" instance "weather_data." It calls the "retrieve_weather_data" method for the current year. If all
three variables are not "None," it appends them to their lists: mean_temps, max_wind_speeds, and precipitation_sums.
After the loop, the lists will contain the mean temperatures, maximum winds speeds, and precipitation sums for each of the
past five years for the specified location and date:
for year in range(2020, 2025):
    mean_temp, max_wind_speed, precipitation_sum = weather_data.retrieve_weather_data(year)
    if all([mean_temp is not None, max_wind_speed is not None, precipitation_sum is not None]):
        mean_temps.append(mean_temp)
        max_wind_speeds.append(max_wind_speed)
        precipitation_sums.append(precipitation_sum)

The next few lines calculate the mean temperature, find the maximum wind speed, and calculate the sum of the precipitation:
mean_temp_5yr = sum(mean_temps) / len(mean_temps) if mean_temps else None
max_wind_speed = max(max_wind_speeds) if max_wind_speeds else None
total_precipitation = sum(precipitation_sums) if precipitation_sums else None

These last three lines print out statements with the output of the results:
print("Mean temperature in Fahrenheit:", mean_temp_5yr)
print("Maximum wind speed in mph:", max_wind_speed)
print("Precipitation sum in inches:", total_precipitation)


