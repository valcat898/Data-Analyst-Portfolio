from sqlalchemy import create_engine, Column, String, Integer, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import sqlite3

#Returns a class
Base = declarative_base()


#Creates a class that will be the base for the class "Weather"
class Weather(Base):
    #Sets a table name "Weather" for the sqlite3 database
    __tablename__: String = "Weather"

    #Specifies the columns and sets prim_id as a unique identifier
    prim_id = Column("prim_id", Integer, primary_key=True)
    latitude = Column("latitude", Float)
    longitude = Column("longitude", Float)
    month = Column("month", Integer)
    day = Column("day", Integer)
    year = Column("year", Integer)
    avg_temp = Column("avg_temp", Float)
    min_temp = Column("min_temp", Float)
    max_temp = Column("max_temp", Float)
    avg_wind_speed = Column("avg_wind_speed", Float)
    min_wind_speed = Column("min_wind_speed", Float)
    max_wind_speed = Column("max_wind_speed", Float)
    sum_precipitation = Column("sum_precipitation", Float)
    min_precipitation = Column("min_precipitation", Float)
    max_precipitation = Column("max_precipitation", Float)

    #Creates a constructor for the table
    def __init__(self, prim_id, latitude, longitude, month, day, year, avg_temp, min_temp, max_temp,
                 avg_wind_speed, min_wind_speed, max_wind_speed, sum_precipitation,
                 min_precipitation, max_precipitation):
        self.prim_id = prim_id
        self.latitude = latitude
        self.longitude = longitude
        self.month = month
        self.day = day
        self.year = year
        self.avg_temp = avg_temp
        self.min_temp = min_temp
        self.max_temp = max_temp
        self.avg_wind_speed = avg_wind_speed
        self.min_wind_speed = min_wind_speed
        self.max_wind_speed = max_wind_speed
        self.sum_precipitation = sum_precipitation
        self.min_precipitation = min_precipitation
        self.max_precipitation = max_precipitation

    #Creates a function that specifies how to print a "Weather" object
    def __repr__(self):
        return f"{self.prim_id} {self.latitude} {self.longitude} {self.month} {self.day} {self.year} {self.avg_temp} {self.min_temp} {self.max_temp} {self.avg_wind_speed} {self.min_wind_speed} {self.max_wind_speed} {self.sum_precipitation} {self.min_precipitation}  {self.max_precipitation}"


#Creates an engine that specifies the database
engine = create_engine("sqlite:///weather.db", echo=True)

#Takes the class that extends from "Base," creates it in the database, and connects the engine
Base.metadata.create_all(bind=engine)

#Creates a session
Session = sessionmaker(bind=engine)
session = Session()

#Inserts data into the columns of the table
weather = Weather(1, 32.7157, -117.1647, 4, 8, 2024, 60.16, 54.4, 75.2, 12.46, 10.8, 14.6, 0.209, 0, 0.209)

#Adds "weather" to the database
session.add(weather)

#Creates "weather" in the actual database and applies the changes to the database
session.commit()
