import unittest

#Creates a class for the unit tests
class TestWeatherData(unittest.TestCase):
    #Creates a test to verify that the formula used for average temperature is correct
    def test_mean_temp(self):
       data = [55.4, 55.7, 75.2, 60.1, 54.4]
       result = sum(data) / len(data)
       self.assertEqual(result, 60.160000000000004)

    #Creates a test to verify that the max wind speed is correct
    def test_max_wind_speed(self):
        data = [13.1, 11.9, 14.6, 10.8, 11.9]
        result = max(data)
        self.assertEqual(result, 14.6)

    #Creates a test to verify that the sum of the precipitation is correct
    def test_precipitation_sum(self):
        data = [0.0, 0.0, 0.0, 0.0, 0.209]
        result = sum(data)
        self.assertEqual(result, 0.209)